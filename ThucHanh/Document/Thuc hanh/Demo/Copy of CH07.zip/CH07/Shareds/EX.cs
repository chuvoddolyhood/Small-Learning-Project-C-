﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CH07
{
    public static class EX
    {
        public static string Cong2Chuoi(this string s1, string s2)
        {
            return s1 + s2;
        }

        public static void HamDemo(int a, int b, int c,int d=0, int e=0, int f = 0)
        {

        }

        public static void Cong<T>(T a, T b)
        {
             
        }
    }
}
