﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CH07
{
    class Person
    {
        private String firstName, lastName, job, gender;
        private int salary, age;

        public Person(String firstName, String lastName, String job, String gender, int age, int salary)
        {
            this.firstName = firstName;
            this.lastName = lastName;
            this.gender = gender;
            this.age = age;
            this.job = job;
            this.salary = salary;
        }

        public static void Main(String[] args)
        {
            List<Person> javaProgrammers = new List<Person>() {
                new Person("Elsdon", "Jaycob", "Java programmer", "male", 43, 2000),
                new Person("Tamsen", "Brittany", "Java programmer", "female", 23, 1500),
                new Person("Floyd", "Donny", "Java programmer", "male", 33, 1800),
                new Person("Sindy", "Jonie", "Java programmer", "female", 32, 1600),
                new Person("Vere", "Hervey", "Java programmer", "male", 22, 1200),
                new Person("Maude", "Jaimie", "Java programmer", "female", 27, 1900),
                new Person("Shawn", "Randall", "Java programmer", "male", 30, 2300),
                new Person("Jayden", "Corrina", "Java programmer", "female", 35, 1700),
                new Person("Palmer", "Dene", "Java programmer", "male", 33, 2000),
                new Person("Addison", "Pam", "Java programmer", "female", 34, 1300)
            };
 
        List<Person> phpProgrammers = new List<Person>() {
                new Person("Jarrod", "Pace", "PHP programmer", "male", 34, 1550),
                new Person("Clarette", "Cicely", "PHP programmer", "female", 23, 1200),
                new Person("Victor", "Channing", "PHP programmer", "male", 32, 1600),
                new Person("Tori", "Sheryl", "PHP programmer", "female", 21, 1000),
                new Person("Osborne", "Shad", "PHP programmer", "male", 32, 1100),
                new Person("Rosalind", "Layla", "PHP programmer", "female", 25, 1300),
                new Person("Fraser", "Hewie", "PHP programmer", "male", 36, 1100),
                new Person("Quinn", "Tamara", "PHP programmer", "female", 21, 1000),
                new Person("Alvin", "Lance", "PHP programmer", "male", 38, 1600),
                new Person("Evonne", "Shari", "PHP programmer", "female", 40, 1800)
            };

            // Basic
        Console.WriteLine("Show programmers name: ");
        javaProgrammers.ForEach(x => Console.WriteLine(x));
        phpProgrammers.ForEach(x => Console.WriteLine(x));

        Console.WriteLine("Increase salary by 5% to programmers:");
        Action<Person> raiseSalary = (x) => x.salary += x.salary * 5 / 100;
        javaProgrammers.ForEach(raiseSalary);
        phpProgrammers.ForEach(raiseSalary);

        Console.WriteLine("Show PHP programmers that earn more than $1,400:");
        phpProgrammers.Where(x => x.salary > 1400).ToList().ForEach(x => Console.WriteLine(x));


         // Define some filters
        Func<Person,bool> ageFilter = (p) => (p.age > 25);
        Func<Person,bool> salaryFilter = (p) => (p.salary > 1400);
        Func<Person,bool> genderFilter = (p) => (p.gender == "female");

        Console.WriteLine("Show female PHP programmers that earn more than $1,400 and are older than 24 years:");
        phpProgrammers.Where(ageFilter).Where(salaryFilter).Where(genderFilter).ToList().ForEach(x => Console.WriteLine(x));

            Console.WriteLine("Show female Java programmers older than 24 years:");
            javaProgrammers.Where(ageFilter).Where(genderFilter).ToList().ForEach(x => Console.WriteLine(x));

        Console.WriteLine("Show first 3 Java programmers:");
        javaProgrammers.Take(3).ToList().ForEach(x => Console.WriteLine(x));

        javaProgrammers.Sort((x, y) => x.lastName.CompareTo(y.lastName));
        javaProgrammers.Take(5).ToList();
        }
    }
}
