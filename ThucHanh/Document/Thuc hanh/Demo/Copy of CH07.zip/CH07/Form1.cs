﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace CH07
{
    public partial class Form1 : Form
    {
        bool is_connected;

        public Form1()
        {
            InitializeComponent();

            string a = "abc";
            string b = "def";
            a.Cong2Chuoi(b);
            EX.HamDemo(3, 4, 5, f: 10);

            object o = new { mssv = "12345", hoten = "Nguyen Van A" };

            List<int> l = new List<int>() { 1, 2, 3, 4, 5, 6, 7, 8, 9 };
            l.ForEach(x => x = x * 2);

            button2.Click += delegate
            {
                MessageBox.Show("Hello");
            };
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            BW.RunWorkerAsync();
            progressBar1.Visible = true;
        }

        private void BW_DoWork(object sender, DoWorkEventArgs e)
        {
            try
            {
                BW.ReportProgress(10);
                SqlConnection con = new SqlConnection("Server=LIGHTX-LT;Database=myDataBase;User Id=sa;Password=myPassword;");
                con.Open();
                is_connected = true;
            }
            catch (SqlException) { };

        }

        private void BW_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            progressBar1.Visible = false;
            if (is_connected) MessageBox.Show("Thành công!");
            else MessageBox.Show("Thất bại");
            
        }

        private void BW_ProgressChanged(object sender, ProgressChangedEventArgs e)
        {
            label1.Text = "Changed";
            progressBar1.Style = ProgressBarStyle.Blocks;
            progressBar1.Value = e.ProgressPercentage;
        }
    }
}
