﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CH04
{
    class DemoCollection
    {
        static void Main()
        {
            // LIST
            List<int> list = new List<int>();
            list.Add(2);
            list.Add(3);
            list.Add(5);
            list.Add(7);
            // list.Add("abc"); <-- Error
            
            int c = list.Count; // Count
            int idx = list.IndexOf(3); // Find and return first value 3 in list. If couldn't found return -1;
            if (list.Contains(5)) ;  // Search for this element.    

            foreach (int prime in list) // Loop through List with foreach.
            {
                Console.WriteLine(prime);
            }

            for (int i = 0; i < list.Count; i++) // Loop with for.
            {
                Console.WriteLine(list[i]);
            }

            // List of cities we need to join.
            List<string> cities = new List<string>();
            cities.Add("New York");
            cities.Add("Mumbai");
            cities.Add("Berlin");
            cities.Add("Istanbul");

            // Join strings into one CSV line.
            string line = string.Join(",", cities.ToArray());
            Console.WriteLine(line);  // Output: New York,Mumbai,Berlin,Istanbul

            // ARRAYLIST is deprecated 
            ArrayList list2 = new ArrayList();
            list2.Add(5);
            list2.Add(1);
            list2.Add("One"); // <--- no error
            int total = 0;
            foreach (int num in list2)
            {
                total += num; //-->Runtime Error
            }

            // DICTIONARY
            Dictionary<string, int> dictionary = new Dictionary<string, int>();

            dictionary.Add("cat", 2);
            dictionary.Add("dog", 1);
            dictionary.Add("llama", 0);
            dictionary.Add("iguana", -1);

            // See whether Dictionary contains this string.
            if (dictionary.ContainsKey("dog"))
            {
                int value = dictionary["dog"];
                Console.WriteLine(value); // Output: 1
            }

            // BITARRAY
            // Create array of 5 elements and 3 true values.
            bool[] array = new bool[5];
            array[0] = true;
            array[1] = false; // <-- False value is default
            array[2] = true;
            array[3] = false;
            array[4] = true;

            // Create BitArray from the array.
            BitArray bitArray = new BitArray(array);

            // Display all bits.
            foreach (bool bit in bitArray)
            {
                Console.WriteLine(bit);
            }

            // HASHTABLE
            Hashtable hashtable = new Hashtable();
            hashtable[1] = "One";
            hashtable[2] = "Two";
            hashtable[13] = "Thirteen";

            foreach (DictionaryEntry entry in hashtable)
            {
                Console.WriteLine("{0}, {1}", entry.Key, entry.Value);
            }

            // TUPLE : A Tuple has many items. Each item can have any type
            // Create three-item tuple.
            Tuple<int, string, bool> tuple = 
                new Tuple<int, string, bool>(1, "cat", true);
            // Access tuple properties.
            if (tuple.Item1 == 1)
            {
                Console.WriteLine(tuple.Item1);
            }
            if (tuple.Item2 == "dog")
            {
                Console.WriteLine(tuple.Item2);
            }
            if (tuple.Item3)
            {
                Console.WriteLine(tuple.Item3);
            }


            // Shows a List of KeyValuePairs.
            var list3 = new List<KeyValuePair<string, int>>();
            list3.Add(new KeyValuePair<string, int>("Cat", 1));
            list3.Add(new KeyValuePair<string, int>("Dog", 2));
            list3.Add(new KeyValuePair<string, int>("Rabbit", 4));

            foreach (var element in list)
            {
                Console.WriteLine(element); // [Cat, 1] [Dog, 2] [Rabbit, 4]
            }

            // STACK
            Stack<int> stack = new Stack<int>();
            stack.Push(100);
            stack.Push(1000);
            stack.Push(10000);

            // Pop the top element
            int pop = stack.Pop();
            // Look at the top element
            int peek = stack.Peek();

            // QUEUE
            // New Queue of integers
            Queue<int> q = new Queue<int>();

            q.Enqueue(5);   // Add 5 to the end of the Queue.
            q.Enqueue(10);  // Then add 10. 5 is at the start.
            q.Enqueue(15);  // Then add 15.
            q.Enqueue(20);  // Then add 20.

            q.Dequeue();
        }
    }
}
