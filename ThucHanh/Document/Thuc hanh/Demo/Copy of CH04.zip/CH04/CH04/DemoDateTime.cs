﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CH04
{
    class DemoDateTime
    {
        static void Main(string[] args)
        {
            // Example using DateTime.
            // ... Write value to Console.
            // ... If this is today, the second line will be True.
            DateTime value = new DateTime(2014, 1, 18);
            Console.WriteLine(value);
            Console.WriteLine(value == DateTime.Today);

            // Write today to Console
            Console.WriteLine("Today: {0}", DateTime.Today);

            // Gets the previous day to the current day.
            DateTime y = DateTime.Today.AddDays(-1);
            Console.WriteLine("Yesterday: {0}", y);

            // Gets the next day, tomorrow.
            DateTime d = DateTime.Today.AddDays(1);
            Console.WriteLine("Tomorrow: {0}", d);

            // Look up the number of days
            int days = DateTime.DaysInMonth(2014, 9); // September. = 30
            Console.WriteLine(days);

            days = DateTime.DaysInMonth(2014, 2); // February. = 28
            Console.WriteLine(days);

            // Create DateTime instances for December 25 and January 1.
            // ... Then compute the difference with Subtract.
            // ... Write the result.
            DateTime christmas = new DateTime(2008, 12, 25);
            DateTime newYears = new DateTime(2009, 1, 1);
            TimeSpan span = newYears.Subtract(christmas);
            Console.WriteLine(span);    // 7.00:00:00
            Console.WriteLine("{0} days", span.TotalDays); // 7 days

            // Get number of days ago.
            DateTime startDate = new DateTime(2008, 3, 3);
            DateTime now = DateTime.Now;
            TimeSpan elapsed = now.Subtract(startDate);
            
            double daysAgo = elapsed.TotalDays;
            Console.WriteLine("{0} was {1} days ago",startDate.ToShortDateString(),daysAgo.ToString("0"));

            // DateTime conversion
            string date = "2000-02-02";
            DateTime ti = DateTime.Parse(date);
            Console.WriteLine(ti);  // Output: 2/2/2000 12:00:00 AM

            // Taken from my head
            string simpleTime = "1/1/2000";
            DateTime time = DateTime.Parse(simpleTime);
            Console.WriteLine(time); // Output: 1/1/2000 12:00:00 AM

            // Taken from HTTP header
            string httpTime = "Fri, 27 Feb 2009 03:11:21 GMT";
            time = DateTime.Parse(httpTime);
            Console.WriteLine(time); // Output: 2/26/2009 7:11:21 PM

            // Taken from w3.org
            string w3Time = "2009/02/26 18:37:58";
            time = DateTime.Parse(w3Time);
            Console.WriteLine(time); // Output: 2/26/2009 6:37:58 PM

            // Taken from nytimes.com
            string nyTime = "Thursday, February 26, 2009";
            time = DateTime.Parse(nyTime);
            Console.WriteLine(time); // Output: 2/26/2009 12:00:00 AM

            // Taken from this site
            string perlTime = "February 26, 2009";
            time = DateTime.Parse(perlTime);
            Console.WriteLine(time); // Output: 2/26/2009 12:00:00 AM

            // Taken from ISO Standard 8601 for Dates
            string isoTime = "2002-02-10";
            time = DateTime.Parse(isoTime);
            Console.WriteLine(time); // Output: 2/10/2002 12:00:00 AM

            // Taken from Windows file system Created/Modified
            string windowsTime = "2/21/2009 10:35 PM";
            time = DateTime.Parse(windowsTime);
            Console.WriteLine(time); // Output: 2/21/2009 10:35:00 PM

            // Taken from Windows Date and Time panel
            string windowsPanelTime = "8:04:00 PM";
            time = DateTime.Parse(windowsPanelTime);
            Console.WriteLine(time); // Output: 2/26/2009 8:04:00 PM

            // using ParseExtract
            string dateString = "Mon 16 Jun 8:30 AM 2008"; // Modified from MSDN
            string format = "ddd dd MMM h:mm tt yyyy";

            DateTime dateTime = DateTime.ParseExact(dateString, format,
                CultureInfo.InvariantCulture);
            Console.WriteLine(dateTime);

            // using TryParseExact
            string dateString2 = "???";
            string format2 = "ddd dd MMM h:mm tt yyyy";
            DateTime dateTime2;
            if (DateTime.TryParseExact(dateString2, format2, CultureInfo.InvariantCulture,
                DateTimeStyles.None, out dateTime2))
            {
                Console.WriteLine(dateTime2);
            }
            else
            {
                Console.WriteLine("Not a date");
            }

            Console.ReadLine();
        }
    }
}
