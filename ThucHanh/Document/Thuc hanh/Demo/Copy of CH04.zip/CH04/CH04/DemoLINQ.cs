﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CH04
{
    class DemoLINQ
    {
        static void Main()
        {
            // Simple example
            int[] arr = { 1, 3, 5, 7 };
            Console.WriteLine(arr.Average());
            // Write simple query.

            // More complex
            int[] array = { 1, 2, 3, 6, 7, 8 };
            // Query expression.
            var elements = from element in array
                           orderby element descending
                           where element > 2
                           select element;
            // Enumerate.
            foreach (var element in elements)
            {
                Console.Write(element); // 8 7 6 3
                Console.Write(' ');
            }
            Console.ReadLine();
        }

    }
}
