﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace CH04
{
    class DemoThread
    {
        static void Main()
        {
            Thread thread1 = new Thread(new ThreadStart(A));
            Thread thread2 = new Thread(new ThreadStart(B));
            thread1.Start();
            thread2.Start();
            thread1.Join();
            thread2.Join();
        }

        static void A()
        {
            Thread.Sleep(100);
            Console.WriteLine('A');
        }

        static void B()
        {
            Thread.Sleep(1000);
            Console.WriteLine('B');
        }

    }
}
