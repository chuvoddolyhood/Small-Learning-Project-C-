﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CH04
{
    class Person
    {
        string firstName { get; set; }
        string lastName { get; set; }
        string job { get; set; }
        string gender { get; set; }

        int salary { get; set; }
        int age { get; set; }

        public Person(string firstName, string lastName, string job, string gender, int age, int salary)
        {
            this.firstName = firstName;
            this.lastName = lastName;
            this.gender = gender;
            this.age = age;
            this.job = job;
            this.salary = salary;
        }

        static void Main()
        {
            List<Person> javaProgrammers = new List<Person>
            {
                new Person("Elsdon", "Jaycob", "Java programmer", "male", 43, 2000),
                new Person("Tamsen", "Brittany", "Java programmer", "female", 23, 1500),
                new Person("Floyd", "Donny", "Java programmer", "male", 33, 1800),
                new Person("Sindy", "Jonie", "Java programmer", "female", 32, 1600),
                new Person("Vere", "Hervey", "Java programmer", "male", 22, 1200),
                new Person("Maude", "Jaimie", "Java programmer", "female", 27, 1900),
                new Person("Shawn", "Randall", "Java programmer", "male", 30, 2300),
                new Person("Jayden", "Corrina", "Java programmer", "female", 35, 1700),
                new Person("Palmer", "Dene", "Java programmer", "male", 33, 2000),
                new Person("Addison", "Pam", "Java programmer", "female", 34, 1300)
            };

            List<Person> phpProgrammers = new List<Person>()
            {
                new Person("Jarrod", "Pace", "PHP programmer", "male", 34, 1550),
                new Person("Clarette", "Cicely", "PHP programmer", "female", 23, 1200),
                new Person("Victor", "Channing", "PHP programmer", "male", 32, 1600),
                new Person("Tori", "Sheryl", "PHP programmer", "female", 21, 1000),
                new Person("Osborne", "Shad", "PHP programmer", "male", 32, 1100),
                new Person("Rosalind", "Layla", "PHP programmer", "female", 25, 1300),
                new Person("Fraser", "Hewie", "PHP programmer", "male", 36, 1100),
                new Person("Quinn", "Tamara", "PHP programmer", "female", 21, 1000),
                new Person("Alvin", "Lance", "PHP programmer", "male", 38, 1600),
                new Person("Evonne", "Shari", "PHP programmer", "female", 40, 1800),
            };

            // Basic
            Console.WriteLine("Show java programmer names: ");
            javaProgrammers.ForEach(p => Console.WriteLine(p.firstName + p.lastName));

            Console.WriteLine("Increase salary by 5% to programmers:");
            Action<Person> giveRaise = (p) => { p.salary += p.salary * 5 / 100; };
            javaProgrammers.ForEach(giveRaise);
            phpProgrammers.ForEach(giveRaise);

            Console.WriteLine("Show PHP programmers that earn more than $1,400:");
            phpProgrammers.Where(p => p.salary > 1400)
                .ToList().ForEach(p => Console.WriteLine(p.firstName + p.lastName));

            // Define some filters
            Func<Person, bool> ageFilter = (p)=> (p.age > 25);
            Func<Person, bool> salaryFilter = (p)=> (p.salary > 1400);
            Func<Person, bool> genderFilter = (p)=> (p.gender=="female");
            Console.WriteLine("Show female PHP programmers that earn more than $1,400 and are older than 24 years:");
            phpProgrammers
                .Where(ageFilter)
                .Where(salaryFilter)
                .Where(genderFilter)
                .ToList().ForEach(p => Console.WriteLine(p.firstName + p.lastName));

            // Reuse filters
            Console.WriteLine("Show female Java programmers older than 24 years:");
            javaProgrammers
                .Where(ageFilter)
                .Where(genderFilter)
                .ToList().ForEach(p => Console.WriteLine(p.firstName + p.lastName));

            Console.WriteLine("Show first 3 Java programmers:");
            javaProgrammers
                .Take(3)
                .ToList().ForEach(p => Console.WriteLine(p.firstName + p.lastName));

            Console.WriteLine("Show first 3 female Java programmers:");
            javaProgrammers
                .Where(genderFilter)
                .Take(3)
                .ToList().ForEach(p => Console.WriteLine(p.firstName + p.lastName));

            Console.WriteLine("Sort and show the first 5 Java programmers by name:");
            javaProgrammers
                .OrderBy(p=> p.firstName)
                .Take(5)
                .ToList().ForEach(p => Console.WriteLine(p.firstName + p.lastName));

            Console.WriteLine("Sort and show the first 5 Java programmers by salary:");
            javaProgrammers
                .OrderBy(p => p.salary)
                .Take(5)
                .ToList().ForEach(p => Console.WriteLine(p.firstName + p.lastName));

            Console.WriteLine("Get the lowest Java programmer salary:");
            Person lowest = javaProgrammers
                .OrderBy(p => p.salary).FirstOrDefault();
            Console.WriteLine(lowest.firstName + lowest.lastName);

            Console.WriteLine("Get the highest Java programmer salary:");
            Person highest = javaProgrammers
                .OrderByDescending(p => p.salary).FirstOrDefault();
            Console.WriteLine(highest.firstName + highest.lastName);

            // Convert
            Console.WriteLine("Get PHP programmers first name to String:");
            string phpDevelopers = string.Join("; ", phpProgrammers.Select(p => p.firstName));

            Console.WriteLine("Calculate total money spent for paying Java programmers:");
            int totalSalary = javaProgrammers.Sum(p => p.salary);
        }
    }
}
