﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace CH04
{
    class DemoBackgroundWorker
    {
        BackgroundWorker bw = new BackgroundWorker();

        public DemoBackgroundWorker()
        {
            bw.DoWork += Bw_DoWork;
            bw.RunWorkerCompleted += Bw_RunWorkerCompleted;
            bw.RunWorkerAsync(); // <-- start
        }

        private void Bw_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            Console.WriteLine("BackgroundWorker completed!"); 
        }

        private void Bw_DoWork(object sender, DoWorkEventArgs e)
        {
            Console.WriteLine("This output using BackgroundWorker.");
        }
    }
}
