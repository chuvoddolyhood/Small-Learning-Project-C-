﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace CH04
{
    class DemoLambda
    {
        static void Main()
        {
            // Simple example
            List<int> elements = new List<int>() { 10, 20, 31, 40 };
            // ... Find index of first odd element.
            int oddIndex = elements.FindIndex(x => x % 2 != 0);
            Console.WriteLine(oddIndex);

            // Func
            //
            // Use implicitly typed lambda expression.
            // ... Assign it to a Func instance.
            //
            Func<int, int> func1 = x => x + 1;
            //
            // Use lambda expression with statement body.
            //
            Func<int, int> func2 = x => { return x + 1; };
            //
            // Use formal parameters with expression body.
            //
            Func<int, int> func3 = (int x) => x + 1;
            //
            // Use parameters with a statement body.
            //
            Func<int, int> func4 = (int x) => { return x + 1; };
            //
            // Use multiple parameters.
            //
            Func<int, int, int> func5 = (x, y) => x * y;
            //
            // Use no parameters in a lambda expression.
            //
            Action func6 = () => Console.WriteLine();
            //
            // Use delegate method expression.
            //
            Func<int, int> func7 = delegate (int x) { return x + 1; };
            //
            // Use delegate expression with no parameter list.
            //
            Func<int> func8 = delegate { return 1 + 1; };
            //
            // Invoke each of the lambda expressions and delegates we created.
            // ... The methods above are executed.
            //
            Console.WriteLine(func1.Invoke(1));
            Console.WriteLine(func2.Invoke(1));
            Console.WriteLine(func3.Invoke(1));
            Console.WriteLine(func4.Invoke(1));
            Console.WriteLine(func5.Invoke(2, 2));
            func6.Invoke();
            Console.WriteLine(func7.Invoke(1));
            Console.WriteLine(func8.Invoke());

            // ACTION
            Action<int> example1 = (int x) => Console.WriteLine("Write {0}", x);
            Action<int, int> example2 = (x, y) => Console.WriteLine("Write {0} and {1}", x, y);
            Action example3 = () => Console.WriteLine("Done");
            // Call the anonymous methods.
            example1.Invoke(1);
            example2.Invoke(2, 3);
            example3.Invoke();


            // PREDICATE
            // This Predicate instance returns true if the argument is one.
            //
            Predicate<int> isOne =
                x => x == 1;
            //
            // This Predicate returns true if the argument is greater than 4.
            //
            Predicate<int> isGreaterEqualFive =
                (int x) => x >= 5;

            //
            // Test the Predicate instances with various parameters.
            //
            Console.WriteLine(isOne.Invoke(1));
            Console.WriteLine(isOne.Invoke(2));
            Console.WriteLine(isGreaterEqualFive.Invoke(3));
            Console.WriteLine(isGreaterEqualFive.Invoke(10));


            // More..
            List<string> players = new List<string> {
                "Rafael Nadal",
                "Novak Djokovic",
                "Stanislas Wawrinka",
                "David Ferrer",
                "Roger Federer",
                "Andy Murray",
                "Tomas Berdych",
                "Juan Martin Del Potro"
            };
            // Old looping
            foreach (string player in players)
            {
                Console.Write(player + ";");
            }
            // using lambda
            players.ForEach(player => Console.Write(player + ";"));

            // Using anonymous methods, TheardStart
            new Thread(delegate()
            {
                Console.WriteLine("Hello world !");
            }).Start();

            // Using lambda
            new Thread(() =>
            {
                Console.WriteLine("Hello world !");
            }).Start();
            
        }
    }
}
