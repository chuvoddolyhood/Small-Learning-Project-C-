﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CH04
{
    class DemoGenericClass
    {
        static void Main()
        {
            // Use the generic type Test with an int type parameter.
            Test<int> test1 = new Test<int>(5);
            // Call the Write method.
            test1.Write();

            // Use the generic type Test with a string type parameter.
            Test<string> test2 = new Test<string>("cat");
            test2.Write();

            // DataTable implements IDisposable so it can be used with Ruby.
            Ruby<DataTable> ruby = new Ruby<DataTable>();

            // Int is a struct (ValueType) so it can be used with Python.
            Python<int> python = new Python<int>();

            // Program is a class with a parameterless constructor (implicit)
            // ... so it can be used with Perl.
            Perl<DemoGenericClass> perl = new Perl<DemoGenericClass>();

        }
    }

    class Test<T>
    {
        T _value;

        public Test(T t)
        {
            // The field has the same type as the parameter.
            this._value = t;
        }

        public void Write()
        {
            Console.WriteLine(this._value);
        }
        
    }

    // Requires type parameter that implements interface IEnumerable.
    class Ruby<T> where T : IDisposable
    {
    }

    // Requires type parameter that is a struct.
    class Python<T> where T : struct
    {
    }

    // Requires type parameter that is a reference type with a constructor.
    class Perl<V> where V : class, new()
    {
    }

}
