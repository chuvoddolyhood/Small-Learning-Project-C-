﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CH04
{
    class DemoAsyncWait
    {
        static void Main()
        {
            Task task = new Task(A);
            task.Start();
            task.Wait();
            Console.WriteLine("All done");
            Console.ReadLine();

        }

        static async void A()
        {
            // This method runs asynchronously.
            int t = await Task.Run(() => B());
            Console.WriteLine("Value from B: " + t);
            Console.WriteLine("Done A");
        }

        static int B()
        {
            int value = 5;
            Console.WriteLine("Secret value is " + value);
            Console.WriteLine("Done B");
            return value;
        }

    }
}
