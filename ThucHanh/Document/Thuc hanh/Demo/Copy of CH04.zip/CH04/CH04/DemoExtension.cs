﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace CH04
{
    static class DemoExtension
    {
        public static string ToUp1(this string s)
        {
            if (string.IsNullOrEmpty(s)) return string.Empty;
            return char.ToUpper(s[0]) + s.Substring(1);
        }

        public static string Truncate(this string value, int maxLength, bool rightToLeft = false)
        {
            if (string.IsNullOrEmpty(value) || value.Length <= maxLength) return value;
            if (rightToLeft) return value.Substring(value.Length - maxLength, maxLength);
            return value.Substring(0, maxLength);
        }

        public static string removeSpecChar(this string value)
        {
            value = Regex.Replace(value, @"NĂM\d{4} ", "");
            value = Regex.Replace(value, @"Năm \d{4} ", "");
            value = Regex.Replace(value, @"NĂM \d{4} ", "");
            value = Regex.Replace(value, "\n", "");
            value = Regex.Replace(value, "- ", "");
            return value.Trim(new Char[] { ' ', '*', '\n', '\t' });
        }
    }
}
